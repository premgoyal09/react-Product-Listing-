import React from 'react';

export default function Card(props) {
    return (
        <div>
            <div className="">
                <img src={props.image} alt="" />
                <h2>{props.title}</h2>
                <span>{props.meta}</span>
                <h5>{props.price}</h5>
                <span>{props.through}</span>
                <h4>{props.discount}</h4>
            </div>
        </div>
    );
}