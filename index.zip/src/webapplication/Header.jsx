import React from 'react';

export default function Header() {
  return (
    <div className="container">
        <h1 className='text-center text-3xl bg-slate-400 py-3 text-white'>Welcome to Vitala Brand</h1>
    </div>
  );
}