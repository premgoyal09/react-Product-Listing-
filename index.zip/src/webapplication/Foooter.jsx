import React from "react";

export default function Footer() {
    return (
        <footer className="bg-gray-800 text-white">
            <div className="container mx-auto px-6 py-10">
                {/* Top Section */}
                <div className="flex flex-col md:flex-row justify-between items-center mb-8">
                    <div className="text-center md:text-left">
                        <h2 className="text-xl font-bold">Your Website Name</h2>
                        <p className="text-gray-400 mt-2">
                            Simplifying the way you manage tasks and track progress.
                        </p>
                    </div>
                    <nav className="mt-6 md:mt-0">
                        <ul className="flex justify-center md:justify-end space-x-6">
                            <li>
                                <a
                                    href="#"
                                    className="text-gray-400 hover:text-white transition-colors"
                                >
                                    Home
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="text-gray-400 hover:text-white transition-colors"
                                >
                                    About
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="text-gray-400 hover:text-white transition-colors"
                                >
                                    Contact
                                </a>
                            </li>
                            <li>
                                <a
                                    href="#"
                                    className="text-gray-400 hover:text-white transition-colors"
                                >
                                    Privacy Policy
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>

                {/* Divider */}
                <hr className="border-gray-600" />

                {/* Bottom Section */}
                <div className="flex flex-col md:flex-row justify-between items-center mt-8">
                    <p className="text-gray-400 text-sm text-center md:text-left">
                        &copy; {new Date().getFullYear()} Your Website Name. All rights reserved.
                    </p>
                    <div className="flex space-x-6 mt-4 md:mt-0">
                        <a
                            href="#"
                            className="text-gray-400 hover:text-white transition-colors"
                            aria-label="Facebook"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-5 w-5"
                                fill="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path d="M22.675 0H1.325C.593 0 0 .593 0 1.326v21.348C0 23.407.593 24 1.325 24H12.82v-9.293H9.692v-3.622h3.128V8.413c0-3.1 1.894-4.787 4.659-4.787 1.325 0 2.463.099 2.794.143v3.242l-1.918.001c-1.504 0-1.794.715-1.794 1.763v2.313h3.586l-.467 3.622h-3.119V24h6.116c.729 0 1.322-.593 1.322-1.326V1.326C24 .593 23.407 0 22.675 0z" />
                            </svg>
                        </a>
                        <a
                            href="#"
                            className="text-gray-400 hover:text-white transition-colors"
                            aria-label="Twitter"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-5 w-5"
                                fill="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path d="M23.954 4.569c-.885.392-1.83.656-2.825.775a4.924 4.924 0 0 0 2.165-2.724 9.86 9.86 0 0 1-3.127 1.195 4.92 4.92 0 0 0-8.384 4.482A13.978 13.978 0 0 1 1.671 3.149 4.905 4.905 0 0 0 3.15 9.722a4.902 4.902 0 0 1-2.23-.616v.061a4.926 4.926 0 0 0 3.95 4.829 4.9 4.9 0 0 1-2.224.085 4.928 4.928 0 0 0 4.6 3.419 9.867 9.867 0 0 1-6.102 2.105c-.396 0-.787-.023-1.175-.067A13.951 13.951 0 0 0 7.548 21c9.057 0 14.01-7.513 14.01-14.01 0-.213-.004-.426-.014-.637A10.012 10.012 0 0 0 24 4.59a9.94 9.94 0 0 1-2.846.779 4.907 4.907 0 0 0 2.146-2.701z" />
                            </svg>
                        </a>
                        <a
                            href="#"
                            className="text-gray-400 hover:text-white transition-colors"
                            aria-label="Instagram"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                className="h-5 w-5"
                                fill="currentColor"
                                viewBox="0 0 24 24"
                            >
                                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 1.366.062 2.633.35 3.608 1.325.974.975 1.262 2.243 1.324 3.608.058 1.266.07 1.646.07 4.851s-.012 3.584-.07 4.85c-.062 1.366-.35 2.633-1.324 3.608-.975.975-2.242 1.263-3.608 1.325-1.266.057-1.646.07-4.85.07s-3.584-.013-4.851-.07c-1.366-.062-2.633-.35-3.608-1.325-.975-.975-1.263-2.242-1.325-3.608-.057-1.266-.07-1.646-.07-4.85s.013-3.584.07-4.851c.062-1.365.35-2.633 1.325-3.608.975-.975 2.242-1.263 3.608-1.325 1.266-.057 1.646-.07 4.851-.07zM12 0C8.741 0 8.332.015 7.052.072 5.773.13 4.48.398 3.318 1.561 2.155 2.723 1.887 4.016 1.83 5.295.772 6.574.015 8.741 0 12c0 3.259.015 3.668.072 4.948.058 1.279.326 2.572 1.489 3.734 1.162 1.162 2.455 1.431 3.734 1.489 1.28.057 1.689.072 4.948.072s3.668-.015 4.948-.072c1.279-.058 2.572-.326 3.734-1.489 1.162-1.162 1.431-2.455 1.489-3.734.057-1.28.072-1.689.072-4.948s-.015-3.668-.072-4.948c-.058-1.279-.326-2.572-1.489-3.734C18.572.326 17.279.058 16 .072 14.72.015 14.309 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zm0 10.162a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.406-11.845a1.44 1.44 0 1 1-2.882-.001 1.44 1.44 0 0 1 2.882 0z" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </footer>
    );
}
