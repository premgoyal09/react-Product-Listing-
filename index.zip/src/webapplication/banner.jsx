import React from 'react';

export default function Banner(props) {
    return (
        <div className='banner-section p-14 flex justify-around  items-center gap-6'>
            <div className="banner-img">
                <img src={props.src} alt="" className='h-[300px] w-[1000px]' />
            </div>
            <div className="banner-text flex flex-col gap-4">
                <h1 className='text-3xl font-bold'>{props.heading}</h1>
                <p className='text-1xl w-[1000px]'>{[props.description]}</p>
            </div>
        </div>
    );
}