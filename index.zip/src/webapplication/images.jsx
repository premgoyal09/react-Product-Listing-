import React, { useState, useEffect } from "react";

export default function Image() {
    const [todos, setTodos] = useState([]);

    // Fetch data
    const getData = async () => {
        try {
            const response = await fetch("https://dummyjson.com/todos");
            const data = await response.json();
            setTodos(data.todos);
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    // Call getData on component mount
    useEffect(() => {
        getData();
    }, []);

    return (
        <div className="container mx-auto p-8">
            <h1 className="text-2xl font-bold text-center mb-6 text-gray-800">
                User Completed or Not Details
            </h1>
            <div className="overflow-x-auto shadow-lg rounded-lg">
                <table className="table-auto w-full border-collapse border border-gray-200 bg-white">
                    <thead className="bg-gray-800 text-white">
                        <tr>
                            <th className="border border-gray-300 px-4 py-2 text-left">Sr</th>
                            <th className="border border-gray-300 px-4 py-2 text-left">Todo</th>
                            <th className="border border-gray-300 px-4 py-2 text-left">Completed</th>
                            <th className="border border-gray-300 px-4 py-2 text-left">User ID</th>
                        </tr>
                    </thead>
                    <tbody>
                        {todos.map((todo, index) => (
                            <tr
                                key={todo.id}
                                className={index % 2 === 0 ? "bg-gray-100" : "bg-white"}
                            >
                                <td className="border border-gray-300 px-4 py-2">{index + 1}</td>
                                <td className="border border-gray-300 px-4 py-2">{todo.todo}</td>
                                <td
                                    className={`border border-gray-300 px-4 py-2 font-semibold ${
                                        todo.completed ? "text-green-600" : "text-red-600"
                                    }`}
                                >
                                    {todo.completed ? "Yes" : "No"}
                                </td>
                                <td className="border border-gray-300 px-4 py-2">{todo.userId}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
}
