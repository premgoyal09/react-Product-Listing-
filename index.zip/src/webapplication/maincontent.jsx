import React from 'react';

export default function MainContent(props) {
    return (
        <div className=''>
            <img src={props.src} alt={props.title} className='h-[600px] w-[100%]'/>
         </div>
    );
}