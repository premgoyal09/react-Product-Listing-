import React from "react";
import { NavLink } from "react-router";


export default function Navbar() {
    return (
        <nav className="bg-gray-800 text-white py-4 shadow-md">
            <div className="container mx-auto flex items-center justify-between px-12">
                <div className="text-xl font-bold">Vitala International Hotel</div>
                <ul className="flex space-x-6">
                    <li className="cursor-pointer">
                        {/* <Link to="/">home</Link> */}
                        {/* <a
                            href="/"
                            className={({ isActive }) =>
                                isActive
                                    ? "text-yellow-400"
                                    : "hover:text-yellow-400 transition-colors duration-300"
                            }
                        >
                            Home
                        </a> */}

                        <NavLink
                            to="/messages"
                            className={({ isActive, isPending }) =>
                                isPending ? "pending" : isActive ? "active" : ""
                            }
                        >
                            Messages
                        </NavLink>
                    </li>
                    <li className="cursor-pointer">
                        <a
                            href="/about"
                            className={({ isActive }) =>
                                isActive
                                    ? "text-yellow-400"
                                    : "hover:text-yellow-400 transition-colors duration-300"
                            }
                        >
                            About
                        </a>
                    </li>
                    <li className="cursor-pointer">
                        <a
                            href="/services"
                            className={({ isActive }) =>
                                isActive
                                    ? "text-yellow-400"
                                    : "hover:text-yellow-400 transition-colors duration-300"
                            }
                        >
                            Services
                        </a>
                    </li>
                    <li className="cursor-pointer">
                        <a
                            href="/location"
                            className={({ isActive }) =>
                                isActive
                                    ? "text-yellow-400"
                                    : "hover:text-yellow-400 transition-colors duration-300"
                            }
                        >
                            Location
                        </a>
                    </li>
                    <li className="cursor-pointer">
                        <a
                            href="/franchise"
                            className={({ isActive }) =>
                                isActive
                                    ? "text-yellow-400"
                                    : "hover:text-yellow-400 transition-colors duration-300"
                            }
                        >
                            Franchise
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    );
}
