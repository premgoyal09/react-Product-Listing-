// import React from 'react';

// export default function App() {
// return (
// <div className='container p-5 m-auto'>
//   <div className="grid grid-cols-4 p-5 justify-center gap-9">
//     <div className='transition-all duration-300'>
//       <img className='transition-transform hover:scale-105' style={{ height: "200px" }} src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQlnIGRh6-5TunpO8cn3XS-IWNqmprhfzsU2Q&s" alt="" />
//       <i className="ri-shield-fill ml-28 mt-3 animate-bounce w-6 h-6" style={{ fontSize: "30px" }}></i>
//       <h1 className='mt-5 transition-transform hover:scale-105' style={{ fontSize: "20px", fontWeight: "bold" }}>Online Ethical Hacking</h1>
//       <p className='transition-transform hover:scale-105'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, voluptatem molestias necessitatibus deleniti maxime vel omnis eaque minus nulla numquam?</p>
//     </div>
//     <div>
//       <img className='transition-transform hover:scale-105' style={{ height: "200px" }} src="https://media.licdn.com/dms/image/v2/D5612AQHyLFkv9YBcGA/article-cover_image-shrink_720_1280/article-cover_image-shrink_720_1280/0/1715058774193?e=2147483647&v=beta&t=7yqv62DbvJWPvycGiDX4FGb79GOPsVB_dreB-SHh36E" alt="" />
//       <i className="ri-fingerprint-line ml-28 mt-3" style={{ fontSize: "30px" }}></i>
//       <h1 className='transition-transform hover:scale-105 mt-5' style={{ fontSize: "20px", fontWeight: "bold" }}>Web Development</h1>
//       <span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, voluptatem molestias necessitatibus deleniti maxime vel omnis eaque minus nulla numquam?</span>
//     </div>
//     <div>
//       <img className='transition-transform hover:scale-105' style={{ height: "200px" }} src="https://beecrowd.com/wp-content/uploads/2024/04/2022-07-19-Melhores-cursos-de-Python.jpg" alt="" />
//       <i className="fa-brands fa-python ml-28 mt-3" style={{ fontSize: "30px" }}></i>
//       <h1 className='transition-transform hover:scale-105 mt-5' style={{ fontSize: "20px", fontWeight: "bold" }}>Python Devlopment</h1>
//       <p className='transition-transform hover:scale-105'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, voluptatem molestias necessitatibus deleniti maxime vel omnis eaque minus nulla numquam?</p>
//     </div>
//     <div>
//       <img className='transition-transform hover:scale-105' style={{ height: "200px" }} src="https://miro.medium.com/v2/resize:fit:800/0*XH3rLskyOsCqVV-j.jpg" alt="" />
//       <i className="fa-solid fa-repeat ml-28 mt-3" style={{ fontSize: "30px" }}></i>
//       <h1 className='transition-transform hover:scale-105 mt-5' style={{ fontSize: "20px", fontWeight: "bold" }}>Full Stack developer</h1>
//       <p className='transition-transform hover:scale-105'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, voluptatem molestias necessitatibus deleniti maxime vel omnis eaque minus nulla numquam?</p>
//     </div>
//   </div>
// </div>
// );
// }





// import React from 'react';
// import Card from './Componnent/Card';

// const users = [
//   {
//     "title": "TEEN TEEN COSMETICS",
//     "meta": "Conceal + Cover Foundation-03",
//     "price": "509",
//     "through": "599",
//     "discount": "(15% OFF)",
//     "image": "https://picsum.photos/id/5/200/300"
//   },
//   {
//     "title": "SWISS BEAUTY",
//     "meta": "Shine & Plump Lip Gloss - 03",
//     "price": "194",
//     "through": "229",
//     "discount": "(15% OFF)",
//     "image": "https://picsum.photos/id/222/200/300"
//   },
//   {
//     "title": "deconstruct",
//     "meta": "Gel Sunscreen-SPF 55+  50g",
//     "price": "331",
//     "through": "349",
//     "discount": "(5% OFF)",
//     "image": "https://picsum.photos/id/12/200/300"
//   },
//   {
//     "title": "RENEE",
//     "meta": "Hot Lips Clear Lip Gloss 4.5ml",
//     "price": "185",
//     "through": "250",
//     "discount": "(26% OFF)",
//     "image": "https://picsum.photos/id/2/200/300"
//   },
// ]

// export default function App() {
//   return (
//     <div className='flex justify-around p-10'>
//       {users.map(function (elem){
//         return(
//           <Card title={elem.title} meta={elem.meta} price={elem.price} through={elem.through} discount={elem.discount} image={elem.image} />
//         )
//       })}
//     </div>
//   );
// }

















// ------------------Tailwind Website -------------------------
import React from 'react';
import Header from './webapplication/Header';
import Home from './webapplication/navbar';
import MainContent from './webapplication/maincontent';
import Banner from './webapplication/banner';
import Image from './webapplication/images';
import Footer from './webapplication/Foooter';
import About from './webapplication/About';
import Services from './webapplication/Services';
import Location from './webapplication/location';
import Franchise from './webapplication/franchise';
import { BrowserRouter, Routes, Route } from 'react-router';


export default function App() {
  return (
    <div>
      <Header />
      <Home />
      <MainContent src="https://miro.medium.com/v2/resize:fit:1400/1*kxBdslclglg4zgCw0NMIIA.png" />


      <Banner src="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto/portal/m/seo/DO_collectionBanner.png" heading="Restaurants Near Me For Dining out" description="Get ready for a delicious adventure packed with unbeatable dining offers at your favorite restaurants. Whether you’re craving a cheesy pizza, a juicy burger, or a delightful bowl of pasta, now is the perfect time to head out and indulge in your favorite meals—while saving big!All the top-rated restaurants and popular eateries are offering enticing deals that are too good to pass up. From buy-one-get-one-free offers to irresistible combo meals, there’s something for everyone. And with a wide variety of restaurant deals near you, enjoying a delectable dining experience has never been more affordable.Picture yourself dining out and savoring a juicy burger with crispy fries, or sharing an oven-fresh pizza topped with all your favorites—all at a fraction of the price. These incredible restaurant offers ensure that you can enjoy delicious meals without worrying about the cost. Whether you’re looking for a casual bite or a special night out, these dining deals make it easy to experience the best without breaking the bank.Planning a night out with friends, a family dinner, or a date night? Take advantage of these fantastic restaurant offers and make every dining experience unforgettable. With top-notch food at unbeatable prices, you can treat yourself and your loved ones to a feast without stretching your budget. Plus, you’ll be supporting local restaurants while enjoying a cost-effective meal out." />

      <Image />
      <Footer />
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/store' element={<About />} />
          <Route path='/services' element={<Services />} />
          <Route path='/location' element={<Location />} />
          <Route path='/Franchise' element={<Franchise />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}